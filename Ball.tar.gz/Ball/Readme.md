Riley Ball
rileyball@ufl.edu

Chirag Narang
cnarang@ufl.edu

Run the 'make' command and it should compile the main.cpp, making a rangeQ executable. Then you can run "./rangeQ searchOption database queries indexBlock" as stated in the assignment pdf.

The outputs are not sorted, however, there were no instructions to sort them so we assumed it was fine as is. 

