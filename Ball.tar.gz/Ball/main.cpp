#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>
#include <sstream>
#include <string>
#include <climits>
#include <limits.h>
#include <map>
#include <chrono>
#include <ctime>

using namespace std;

struct Node{
    bool leaf;
    int nonLeafVal;
    multimap<int, vector<int> > records;
    Node *left, *right;
    Node(vector<vector<int> > arr, int k, bool temp, int val, int depth){
        for(int i = 0; i < arr.size(); i++){
            vector<int> temp;
            for(int j = 0; j < k; j++){
                temp.push_back(arr[i][j]);
            }
            records.insert(make_pair(temp[depth % k], temp));
        }
        right = left = nullptr;
        leaf = temp;
        nonLeafVal = val;
    }
    Node(multimap<int, vector<int> > arr, int k, bool temp, int val, int depth){
        for(auto iter = arr.begin(); iter != arr.end(); iter++){
            records.insert(make_pair(iter->second[depth % k], iter->second));
        }
        right = left = nullptr;
        leaf = temp;
        nonLeafVal = val;
    }
};

Node* splitNode(Node* root, multimap<int, vector<int> >& v, int depth, int k, int maxsize){
    int currAttr = (depth % k), half = (v.size()/2), cnt = 0, halfval = 0;
    //cout << "curr level " << currAttr << endl;
    //cout << "split node ";
    multimap<int, vector<int> > temptotal, leftv, rightv;
    for(auto iter = v.begin(); iter != v.end(); iter++){
        temptotal.insert(make_pair(iter->second[currAttr], iter->second));
    }
    for(auto iter = temptotal.begin(); iter != temptotal.end(); iter++){
        if(cnt < half){
            leftv.insert(make_pair(iter->second[currAttr], iter->second));
        }
        else{
            if(cnt == half){
                halfval = iter->second[currAttr];
            }
            rightv.insert(make_pair(iter->second[currAttr], iter->second));
        }
        cnt++;
    }

    root->leaf = false;
    root->nonLeafVal = halfval;
    //Node* nonLeaf = new Node(v, k, false, halfval, depth);
    root->left = new Node(leftv, k, true, -1, depth);
    root->right = new Node(rightv, k, true, -1, depth);

    return root;
}

Node* insertKD(Node* root, vector<int>& v, int depth, int k, int maxsize){
    if(!root){
        vector< vector<int> > vec;
        vec.push_back(v);
        return new Node(vec, k, true, -1, depth);
    }

    //index of current attribute
    int currAttr = depth % k;
    //cout<< "should match " << currAttr << endl;

    if(root->leaf){
        if(root->records.size() < maxsize){
            root->records.insert(make_pair(v[currAttr], v));
            return root;
        }
        else{
            //make sure we take care of/ add the new record v into the array for root*****************************************************
            root->records.insert(make_pair(v[currAttr], v));
            root = splitNode(root, root->records, depth, k, maxsize);
            return root;
        }
    }
    else{
        if(v[currAttr] < root->nonLeafVal){
            root->left = insertKD(root->left, v, depth + 1, k, maxsize);
        }
        else{
            root->right = insertKD(root->right, v, depth + 1, k, maxsize);
        }
    }

    return root;
}

void search(Node* root, vector<pair<int, int> >& bounds, int depth, int k){
    if(!root){
        return;
    }
    int currAttr = depth % k;
    if(root->leaf){
        for(auto iter = root->records.begin(); iter != root->records.end(); iter++){
            bool temp = true;
            for(int i = 0; i < bounds.size(); i++){
                if(iter->second[i] < bounds[i].first || iter->second[i] > bounds[i].second){
                    temp = false;
                }
            }
            if(temp){
                for(int i = 0; i < bounds.size(); i++){
                    cout << iter->second[i] << " ";
                }
                cout << endl;
            }
        }
    }
    else{
        if(bounds[currAttr].first <= root->nonLeafVal && bounds[currAttr].second >= root->nonLeafVal){
            search(root->left, bounds, depth + 1, k);
            search(root->right, bounds, depth + 1, k);
        }
        else{
            if(bounds[currAttr].first >= root->nonLeafVal){
                search(root->right, bounds, depth + 1, k);
            }
            if(bounds[currAttr].second <= root->nonLeafVal){
                search(root->left, bounds, depth + 1, k);
            }
        }
    }
    return;
}

Node* splitMyKDNode(Node* root, multimap<int, vector<int> >& v, int depth, int k, int maxsize){
    int currAttr = (depth % k), half = (v.size()/2), cnt = 0, halfval = 0;
    multimap<int, vector<int> > temptotal, leftv, rightv;
    for(auto iter = v.begin(); iter != v.end(); iter++){
        temptotal.insert(make_pair(iter->second[currAttr], iter->second));
    }
    for(auto iter = temptotal.begin(); iter != temptotal.end(); iter++){
        if(cnt < half){
            leftv.insert(make_pair(iter->second[currAttr], iter->second));
        }
        else{
            if(cnt == half){
                halfval = iter->second[currAttr];
            }
            rightv.insert(make_pair(iter->second[currAttr], iter->second));
        }
        cnt++;
    }

    root->leaf = false;
    root->nonLeafVal = halfval;
    root->left = new Node(leftv, k, true, -1, depth);
    root->right = new Node(rightv, k, true, -1, depth);

    return root;
}

Node* insertMyKD(Node* root, vector<int>& v, int depth, int k, int maxsize){
    if(!root){
        vector< vector<int> > vec;
        vec.push_back(v);
        return new Node(vec, k, true, -1, depth);
    }

    //index of current attribute
    int currAttr = depth % k;
    //cout<< "should match " << currAttr << endl;

    if(root->leaf){
        if(root->records.size() < maxsize){
            root->records.insert(make_pair(v[currAttr], v));
            return root;
        }
        else{
            //make sure we take care of/ add the new record v into the array for root*****************************************************
            root->records.insert(make_pair(v[currAttr], v));
            root = splitMyKDNode(root, root->records, depth, k, maxsize);
            return root;
        }
    }
    else{
        if(v[currAttr] < root->nonLeafVal){
            root->left = insertMyKD(root->left, v, depth + 1, k, maxsize);
        }
        else{
            root->right = insertMyKD(root->right, v, depth + 1, k, maxsize);
        }
    }

    return root;
}

int main(int argc, char* argv[]){
    int searchOption = stoi(argv[1]), indexBlock;
    string databaseName = argv[2], queries = argv[3];

    auto start = std::chrono::high_resolution_clock::now();

    if(searchOption == 0){
        ifstream db;
        db.open(databaseName);
        string record;
        vector<vector<int> > allRecords;
        while(getline(db, record)){
            stringstream ss(record);
            string attribute;
            vector<int> attrs;
            while(getline(ss, attribute, ',')){
                attrs.push_back(stoi(attribute));
            }
            allRecords.push_back(attrs);
        }
        db.close();

        //we now have a vector of all records

        ifstream q;
        q.open(queries);
        string line;
        vector<vector<pair<int, int> > > bounds;
        while(getline(q, line)){
            stringstream sstr(line);
            string minattr, maxattr;
            vector<pair<int, int> > pairs;
            for(int i = 0; i < allRecords[0].size(); i++){
                getline(sstr, minattr, ' ');
                getline(sstr, maxattr, ' ');
                pairs.push_back(make_pair(stoi(minattr), stoi(maxattr)));
            }
            bounds.push_back(pairs);
        }
        q.close();

        start = std::chrono::high_resolution_clock::now();

        //search the records
        //we have all the records
        //we have a list of bounds for each dimension in each query

        for(int l = 0; l < bounds.size(); l++){
            //print out query
            for(int i = 0; i < bounds[l].size(); i++){
                cout << bounds[l][i].first << " " << bounds[l][i].second << " ";
            }
            cout << endl;

            for(int i = 0; i < allRecords.size(); i++){
                bool inRange = true;
                for(int j = 0; j < allRecords[i].size(); j++){
                    if(allRecords[i][j] < bounds[l][j].first || allRecords[i][j] > bounds[l][j].second){
                        inRange = false;
                    }
                }
                if(inRange){
                    for(int m = 0; m < allRecords[i].size(); m++){
                        cout << allRecords[i][m] << " ";
                    }
                    cout << endl;
                }
            }
        }
    }
    else if(searchOption == 1){
        indexBlock = stoi(argv[4]);

        ifstream db;
        db.open(databaseName);
        string record;
        vector<vector<int> > allRecords;
        while(getline(db, record)){
            stringstream ss(record);
            string attribute;
            vector<int> attrs;
            while(getline(ss, attribute, ',')){
                attrs.push_back(stoi(attribute));
            }
            allRecords.push_back(attrs);
        }
        db.close();


        //we now have a vector of all records

        ifstream q;
        q.open(queries);
        string line;
        vector<vector<pair<int, int> > > bounds;
        while(getline(q, line)){
            stringstream sstr(line);
            string minattr, maxattr;
            vector<pair<int, int> > pairs;
            for(int i = 0; i < allRecords[0].size(); i++){
                getline(sstr, minattr, ' ');
                getline(sstr, maxattr, ' ');
                pairs.push_back(make_pair(stoi(minattr), stoi(maxattr)));
            }
            bounds.push_back(pairs);
        }
        q.close();

        Node* root = nullptr;
        for(int i = 0; i < allRecords.size(); i++){           
            root = insertKD(root, allRecords[i], 0, allRecords[i].size(), indexBlock);
        }

        start = std::chrono::high_resolution_clock::now();

        for(int l = 0; l < bounds.size(); l++){
            //print out query
            for(int i = 0; i < bounds[l].size(); i++){
                cout << bounds[l][i].first << " " << bounds[l][i].second << " ";
            }
            cout << endl;
            search(root, bounds[l], 0, allRecords[0].size());
            cout << flush;
        }

    }
    else if(searchOption == 2){
        indexBlock = stoi(argv[4]);

        ifstream db;
        db.open(databaseName);
        string record;
        vector<vector<int> > allRecords;
        while(getline(db, record)){
            stringstream ss(record);
            string attribute;
            vector<int> attrs;
            while(getline(ss, attribute, ',')){
                attrs.push_back(stoi(attribute));
            }
            allRecords.push_back(attrs);
        }
        db.close();


        //we now have a vector of all records

        ifstream q;
        q.open(queries);
        string line;
        vector<vector<pair<int, int> > > bounds;
        while(getline(q, line)){
            stringstream sstr(line);
            string minattr, maxattr;
            vector<pair<int, int> > pairs;
            for(int i = 0; i < allRecords[0].size(); i++){
                getline(sstr, minattr, ' ');
                getline(sstr, maxattr, ' ');
                pairs.push_back(make_pair(stoi(minattr), stoi(maxattr)));
            }
            bounds.push_back(pairs);
        }
        q.close();

        Node* root = nullptr;
        for(int i = 0; i < allRecords.size(); i++){           
            root = insertMyKD(root, allRecords[i], 0, allRecords[i].size(), indexBlock);
        }

        start = std::chrono::high_resolution_clock::now();

        for(int l = 0; l < bounds.size(); l++){
            //print out query
            for(int i = 0; i < bounds[l].size(); i++){
                cout << bounds[l][i].first << " " << bounds[l][i].second << " ";
            }
            cout << endl;
            search(root, bounds[l], 0, allRecords[0].size());
        }

    }


    auto end = std::chrono::high_resolution_clock::now();
    cout << "Execution time: " << chrono::duration_cast<chrono::microseconds>(end - start).count() << endl;
    return 0;
}

